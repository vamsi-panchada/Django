from django.contrib import admin

# Register your models here.
from blogApp.models import blogPost

admin.site.register(blogPost)