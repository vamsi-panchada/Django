
from django import forms

from blogApp.models import blogPost


class blogPostForm(forms.ModelForm):
    class Meta:
        model = blogPost
        fields = ('title', 'body', )