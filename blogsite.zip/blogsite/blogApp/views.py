from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from datetime import datetime
# Create your views here.
from blogApp.forms import blogPostForm
from blogApp.models import blogPost


def index(request):
    return HttpResponse("Hello world!")

def home(request):
    return render(request, 'home.html')

def archive(request):
    posts = blogPost.objects.all()
    return render(request, 'archive.html', {'posts_list':posts})

def create(request):
    if request.method == 'POST':
        form = blogPostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.timestamp = datetime.now()
            post.save()
            return HttpResponseRedirect('/')
        else:
            form.blogPostForm(request.POST)
            return render(request, 'create.html', {'form': form})
    else:
        form = blogPostForm(request.POST)
        return render(request, 'create.html', {'form': form})