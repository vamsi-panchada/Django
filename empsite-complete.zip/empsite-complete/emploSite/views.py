from django.http import HttpResponseRedirect
from django.shortcuts import render

# Create your views here.
from emploSite.forms import employeeForm
from emploSite.models import employee


def index(request):
    return render(request, 'home.html')

def create(request):
    form = employeeForm()
    if request.method == 'POST':
        form = employeeForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('./display')
    return render(request, 'insert.html', context={'form':form})

def display(request):
    emplo = employee.objects.all()
    return render(request, 'display.html', {'employee':emplo})

def del_view(request, id):
    emp = employee.objects.get(id=id)
    emp.delete()
    return HttpResponseRedirect('../display')

def update_view(request, id):
    emp = employee.objects.get(id=id)
    if request.method == 'POST':
        form = employeeForm(request.POST, instance=emp)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('../display')
    return render(request, 'update.html', context={'employee':emp})

