from django.urls import path

from emploSite import views

urlpatterns = [
    path('home',views.index),
    path('',views.index),
    path('create', views.create),
    path('display', views.display),
    path('delete/<int:id>', views.del_view),
    path('update/<int:id>', views.update_view),
]